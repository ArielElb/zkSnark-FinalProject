use rand::Rng;
use std::{io, u128};

fn calculate_sd(n: u128) -> (u128, u32) {
    let mut d = n - 1;
    let mut s = 0;

    while d % 2 == 0 {
        d /= 2;
        s += 1;
    }

    (s, d.try_into().unwrap())
}
fn power(base:u128,exp:u32,n: u128) -> u128 {
    let mut res = 1;
    for _i in 0..exp {
        res = (res*base)%n;
    }
    return res;
}
fn miller_rabin(n:u128, k:u32)->bool{
    // implementing miller rabin test in rust
    let (s,d) = calculate_sd(n-1);
    let mut y = 1;
    for _i in 0..k {
        let mut rng = rand::thread_rng();
        let a: u128 = rng.gen_range(2..=n-2);
        let mut x = power(a, d, n);//a.pow(d) % n;
        for _j in 0..s{
            y = (x%n*x%n) % n;
            if (y == 1 && x != 1 && x != n-1){
                return false
            }
            x = y;
        }
        if y != 1 {
            return false;
        }
    }
    return true;
}

fn main() {
    let k = 100;

    println!("Please enter an integer:");

    // Create a mutable string to store the user input
    let mut input_text = String::new();

    // Read a line of input from the standard input and store it in input_text
    io::stdin()
        .read_line(&mut input_text)
        .expect("Failed to read line");

    // Attempt to parse the input string into an integer
    let input_num: u128 = match input_text.trim().parse() {
        Ok(num) => num,
        Err(_) => {
            println!("Please enter a valid integer.");
            return;
        }
    };
    println!("{}",miller_rabin(input_num, k));
}

